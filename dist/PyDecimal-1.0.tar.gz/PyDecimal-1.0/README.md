# PyBase
pythonの進数変換系ライブラリです
