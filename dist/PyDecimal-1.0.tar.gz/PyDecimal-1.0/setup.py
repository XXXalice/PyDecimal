from setuptools import setup

setup(
    packages=[
        'PyDecimal'
    ],
    name='PyDecimal',
    version='1.0',
    description='Convert base number',
    author='umemiya',
    author_email='euthanasia045@gmail.com',
    license='MIT',

    keywords='math convert base'
)